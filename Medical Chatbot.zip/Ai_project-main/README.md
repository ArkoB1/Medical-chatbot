# Ai_project
CAUTION: Please run the project only in virtual environment due to dependencies versions
## Direct command line to project directory and run the following commands one by one:
- py -m venv env
- .\env\Scripts\activate
- pip3 install -r requirements.txt
## Training model 
python train_chatbot.py
## Final UI 
python chatgui.py
## Description 
- chatgui contains front end of the project that is UI and train_chatbot is Sequential Neural Network Model
- intents.json contains dataset
- requirements contains dependencies with their versions which help in executing project successfully

